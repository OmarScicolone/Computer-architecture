/*********************************************************************************************************
**--------------File Info---------------------------------------------------------------------------------
** File name:           IRQ_RIT.c
** Last modified Date:  2014-09-25
** Last Version:        V1.00
** Descriptions:        functions to manage T0 and T1 interrupts
** Correlated files:    RIT.h
**--------------------------------------------------------------------------------------------------------
*********************************************************************************************************/
#include "lpc17xx.h"
#include "RIT.h"
#include "../led/led.h"

/******************************************************************************
** Function name:		RIT_IRQHandler
**
** Descriptions:		REPETITIVE INTERRUPT TIMER handler
**
** parameters:			None
** Returned value:		None
**
******************************************************************************/

// sta cosa viene chiamata ogni 50 ms, quindi ogni volta down (avendo mantenuto il valore
// attribuitogli nella chiamata precedente) aumenta di 1.

void RIT_IRQHandler (void)
{	
	static uint8_t premuto1 = 0;	
	static uint8_t premuto2 = 0;	
	static int down=0;	
	static uint8_t position = 0;
	down++;
	
	if( ((LPC_GPIO2->FIOPIN & (1<<12)) == 0) || premuto2 ){			// premuto EINT2 - DECREMENTO
		
		if((LPC_GPIO2->FIOPIN & (1<<12)) == 0){
		//static uint8_t position = 0;
		premuto2 = 1;	
		
		reset_RIT();
		switch(down){
			case 1:
				if( position == 0){
					LED_On(7);
					LED_Off(0);
					position = 7;
				}
				else{
					LED_Off(position);
					LED_On(--position);
				}
				break;
			default:
				break;
		}
	}
		else {
			premuto2 = 0;
			down=0;			
			disable_RIT();
			reset_RIT();
			NVIC_EnableIRQ(EINT2_IRQn);							 /* disable Button interrupts			*/
			LPC_PINCON->PINSEL4    |= (1 << 24);     /* External interrupt 0 pin selection */
		}
	}

	
// ----------------------------------------------------------------------------------------------------------------------	
	
	if( ((LPC_GPIO2->FIOPIN & (1<<11)) == 0) || premuto1 ){			// premuto EINT1 - INCREMENTO
		
		if((LPC_GPIO2->FIOPIN & (1<<11)) == 0){
		//static uint8_t position = 0;
		premuto1 = 1;	
		
		reset_RIT();
		switch(down){
			case 1:
				if( position == 7){
					LED_On(0);
					LED_Off(7);
					position = 0;
				}
				else{
					LED_Off(position);
					LED_On(++position);
				}
				break;
			default:
				break;
		}
	}
		else {
			premuto1 = 0;
			down=0;			
			disable_RIT();
			reset_RIT();
			NVIC_EnableIRQ(EINT1_IRQn);							 /* disable Button interrupts			*/
			LPC_PINCON->PINSEL4    |= (1 << 22);     /* External interrupt 0 pin selection */
		}
	}
		
	
  LPC_RIT->RICTRL |= 0x1;	/* clear interrupt flag */
	
  return;
}

/******************************************************************************
**                            End Of File
******************************************************************************/
